package com.dicoding.dicodingfundamental

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.dicodingfundamental.data.response.Event
import com.dicoding.dicodingfundamental.data.response.EventResponse
import com.dicoding.dicodingfundamental.databinding.ItemEventBinding

class EventAdapter(private val listEvent: ArrayList<EventResponse>) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_event, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = listEvent[position]
        holder.bind(event)
    }

    override fun getItemCount(): Int {
        return listEvent.size
    }

    fun setData(newList: List<EventResponse>) {
        listEvent.clear()
        listEvent.addAll(newList)
        notifyDataSetChanged()
    }

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(event: EventResponse) {
            // Bind data to views
            itemView.findViewById<TextView>(R.id.tv_event_name).text = event.name
            itemView.findViewById<TextView>(R.id.tv_event_quota).text = event.ownerName
            Glide.with(itemView.context)
                .load(event.imageLogo)
                .into(itemView.findViewById(R.id.iv_event_logo))
        }
    }
}
