package com.dicoding.dicodingfundamental

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.dicodingfundamental.data.response.Event
import com.dicoding.dicodingfundamental.data.response.EventResponse
import com.dicoding.dicodingfundamental.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EventViewModel : ViewModel() {

    private val _upcomingEvents = MutableLiveData<List<EventResponse>>()
    val upcomingEvents: LiveData<List<EventResponse>> = _upcomingEvents

    private val _finishedEvents = MutableLiveData<List<EventResponse>>()
    val finishedEvents: LiveData<List<EventResponse>> = _finishedEvents

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val apiService = ApiConfig.getApiService()

    // Function to fetch upcoming events
    fun getUpcomingEvents() {
        _isLoading.value = true
        apiService.getActiveEvent()
            .enqueue(object : Callback<Event> { // Ganti dari EventResponse menjadi Event
                override fun onResponse(call: Call<Event>, response: Response<Event>) {
                    _isLoading.value = false
                    if (response.isSuccessful) {
                        // Akses listEvents dari response.body(), yang merupakan objek Event
                        _upcomingEvents.value = response.body()?.listEvents ?: listOf()
                    }
                }

                override fun onFailure(call: Call<Event>, t: Throwable) {
                    _isLoading.value = false
                }
            })
    }


    // Function to fetch finished events
    fun getFinishedEvents() {
        _isLoading.value = true
        apiService.getNonActiveEvent()
            .enqueue(object : Callback<Event> { // Sama seperti getUpcomingEvents(), gunakan Event
                override fun onResponse(call: Call<Event>, response: Response<Event>) {
                    _isLoading.value = false
                    if (response.isSuccessful) {
                        // Akses listEvents dari response.body(), yang merupakan objek Event
                        _finishedEvents.value = response.body()?.listEvents ?: listOf()
                    }
                }

                override fun onFailure(call: Call<Event>, t: Throwable) {
                    _isLoading.value = false
                }
            })
    }
}
