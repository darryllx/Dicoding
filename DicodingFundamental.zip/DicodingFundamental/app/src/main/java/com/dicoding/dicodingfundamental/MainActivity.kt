package com.dicoding.dicodingfundamental

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.dicodingfundamental.data.response.Event
import com.dicoding.dicodingfundamental.data.response.EventResponse
import com.dicoding.dicodingfundamental.data.retrofit.ApiConfig
import com.dicoding.dicodingfundamental.data.retrofit.ApiService
import com.dicoding.dicodingfundamental.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: EventAdapter
    private val listEvent: ArrayList<EventResponse> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        fetchDataFromApi()
    }

    private fun setupRecyclerView() {
        adapter = EventAdapter(listEvent)
        binding.rvEvents.layoutManager = LinearLayoutManager(this)
        binding.rvEvents.adapter = adapter
    }

    private fun fetchDataFromApi() {
        val client = ApiConfig.getApiService().getAllEvent()
        client.enqueue(object : Callback<Event> {
            override fun onResponse(call: Call<Event>, response: Response<Event>) {
                if (response.isSuccessful) {
                    val eventResponse = response.body()
                    if (eventResponse != null && !eventResponse.error) {
                        // Tambahkan data ke list jika tidak null
                        listEvent.addAll(eventResponse.listEvents ?: emptyList())
                        adapter.notifyDataSetChanged()
                    } else {
                        Log.e("MainActivity", "onResponse: No events found")
                    }
                } else {
                    Log.e("MainActivity", "onResponse: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<Event>, t: Throwable) {
                Log.e("MainActivity", "onFailure: ${t.message.toString()}")
            }
        })
    }


}
