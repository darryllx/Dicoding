package com.dicoding.dicodingfundamental.data.retrofit

import com.dicoding.dicodingfundamental.data.response.Event
import com.dicoding.dicodingfundamental.data.response.EventResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("events?active=1")
    fun getActiveEvent(): Call<Event>

    @GET("events?active=0")
    fun getNonActiveEvent(): Call<Event>

    @GET("events")
    fun getAllEvent(): Call<Event>

    @GET("events/{id}")
    fun getDetail(): Call<Event>
}