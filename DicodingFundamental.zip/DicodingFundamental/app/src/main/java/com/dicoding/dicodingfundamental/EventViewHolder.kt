package com.dicoding.dicodingfundamental

class EventViewHolder {

}
