package com.dicoding.dicodingfundamental

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.lifecycle.ViewModelProvider
import com.dicoding.dicodingfundamental.databinding.FragmentUpcomingBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class UpcomingFragment : Fragment() {

    private lateinit var viewModel: EventViewModel
    private lateinit var adapter: EventAdapter
    private lateinit var binding: FragmentUpcomingBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentUpcomingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = EventAdapter(arrayListOf())
        binding.rvUpcomingEvents.adapter = adapter

        viewModel = ViewModelProvider(this)[EventViewModel::class.java]

        viewModel.upcomingEvents.observe(viewLifecycleOwner) { events ->
            adapter.setData(events)
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.getUpcomingEvents()
    }
}
