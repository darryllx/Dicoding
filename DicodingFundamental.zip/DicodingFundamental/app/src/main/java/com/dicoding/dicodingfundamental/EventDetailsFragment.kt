package com.dicoding.dicodingfundamental

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.dicoding.dicodingfundamental.data.response.Event
import com.dicoding.dicodingfundamental.data.response.EventResponse
import com.dicoding.dicodingfundamental.databinding.FragmentEventDetailsBinding

class EventDetailsFragment : Fragment() {


}